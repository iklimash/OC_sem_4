#!/bin/bash
gcc -c lab2_3.c
gcc -o lab2_3 lab2_3.o -lpthread
./lab2_3