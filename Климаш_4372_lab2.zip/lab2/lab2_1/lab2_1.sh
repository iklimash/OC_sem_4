#!/bin/bash
gcc -c lab2_1.c
gcc -o lab2_1 lab2_1.o -lpthread
./lab2_1