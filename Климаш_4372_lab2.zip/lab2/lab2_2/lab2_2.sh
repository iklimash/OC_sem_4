#!/bin/bash
gcc -c lab2_2.c
gcc -o lab2_2 lab2_2.o -lpthread
./lab2_2